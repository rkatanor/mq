export interface Auditdashboard {
    entID: string;
    queueName: string;
    queueManager: string;
    messageID: string;
    logTime: Date;
}
